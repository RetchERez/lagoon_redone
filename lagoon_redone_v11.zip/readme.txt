Lagoon Redone v1.1
By RetchERezzed

For Lagoon (USA) on Super Nintendo
Clean ROM CRC32: D2554270
Patched ROM CRC32: 37B8CEAA

ABOUT

Lagoon Redone makes the original adventure more comfortable to play with
more forgiving sword combat, a gentler opening, less grinding, improved
jumping and a camera that follows Nasir immediately

The original story, maps, enemies, equipment, magic system and boss design
are preserved

CHANGELOG - v1.1

- Giles and Thor stay closer before settling into their follow behavior
- Nearby companions can pass exits without waiting for the original
  camera-based position requirement; distant companions still need to catch up
- Ordinary HP recovery while standing still outside towns is 50% faster
- Town recovery, MP recovery, ring effects and boss-room recovery rules remain
  as before; moving and taking action still interrupt ordinary recovery

These are independently written changes for Redone

CHANGELOG - v1.0

Initial release

- Modestly increased sword reach in all four directions
- A shaded steel blade with a compact hilt and clearer side and downward views
- Eight extra frames of protection after an ordinary hit
- Starting HP increased to 18 and base defense to 11, with adjusted level 2 growth
- Enemy and boss EXP increased by 50%, rounded down to whole numbers
- A brief eight-frame hold at the original jump peak for a little more airtime
  and distance while moving
- Immediate camera following with matching placement when entering rooms

Nasir's contact hitbox and normal shield behavior are preserved
Small EXP rewards may remain unchanged after rounding
Magic remains unavailable during boss fights
Companions retain their normal movement speed and wall collision
Pit hazards and the original need to wait for distant companions remain
FastROM and restored story content are not included

INSTALLATION

1) Make a backup of your ROM and save files
2) Use a clean, headerless Lagoon (USA).sfc ROM, exactly 1,048,576 bytes
3) Apply lagoon_redone_v11.ips using Floating IPS or another IPS patcher
4) The patched ROM will be 2,097,152 bytes
5) Start a new game to receive the revised starting HP and defense

Apply this patch directly to the clean original ROM, including when updating
from v1.0; do not apply it over Redone v1.0 or another hack
Keep a backup of existing saves; loading a save retains its stored stats
Emulator save states should be recreated after changing ROM versions

Clean ROM SHA-1: 416AAD89D76D4A74E2DB985DB1AEE3A50DBAFEC8

CONTENTS

- lagoon_redone_v11.ips
- readme.txt

THANKS

Thanks to darrylthom for the companion and HP recovery suggestions

No ROM is included; supply your own legal copy of the game
