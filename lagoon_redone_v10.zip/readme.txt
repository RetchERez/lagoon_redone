Lagoon Redone v1.0
By RetchERezzed

ROM CRC32
---------
Before patching: D2554270
After patching:  0DE7273E

The first CRC belongs to the clean Lagoon (USA) ROM you need to apply the
patch. The second belongs to the finished Lagoon Redone ROM. The name of a
ROM file alone does not identify its contents.

ABOUT
-----
Lagoon Redone improves the feel of the original Super Nintendo adventure.
Sword attacks are easier to line up, early mistakes are less punishing,
leveling requires less grinding, and jumping and camera movement feel more
comfortable. The changes are modest and keep the original game's character.

The story, maps, enemy roster, magic, equipment list and boss design remain
faithful to the original game.

WHAT'S NEW
----------
- Sword reach - All four attack directions receive a modest reach increase,
  making it easier to connect without getting quite so close to an enemy
- Sword appearance - A shaded steel blade, compact grip and guard, and slightly
  longer side and downward views give the sword a clearer shape during attacks
- Recovery after damage - Eight extra frames of protection after an ordinary
  hit give Nasir a little more time before he can take another hit
- Less grinding - Enemy and boss EXP rewards increase by 50%, rounded down to
  whole numbers; a 2 EXP reward becomes 3, while a 1 EXP reward stays at 1
- Early survivability - Starting HP increases from 10 to 18 and base defense
  from 5 to 11; level 2 gives 21 maximum HP and 13 base defense
- Jumping - An extra eight frames at the original jump peak give a little more
  time in the air; holding a direction carries Nasir slightly farther
- Camera movement - The camera follows as Nasir moves, with matching placement
  when entering rooms; at map edges, the view stops at the room boundary

Normal enemy contact is still dangerous. A correctly facing shield can push
some enemies away, just as it does in the original game.

REQUIRED ROM
------------
Game: Lagoon (USA)
Filename: Lagoon (USA).sfc
Format: Headerless
Original size: 1,048,576 bytes
Patched size: 2,097,152 bytes

Headerless means the ROM has no extra 512-byte copier header. Use the clean
USA release, not a previously patched ROM. The larger finished file is normal.

HOW TO INSTALL
--------------
- Back up your clean Lagoon (USA) ROM
- Open a patcher that supports BPS patches
- Select your clean, headerless ROM as the original file
- Select lagoon_redone_v10.bps as the patch
- Save the result under a new filename, such as lagoon_redone_v10.sfc
- Open the patched game in your SNES emulator and start a new game

Apply this patch directly to the clean ROM. Do not apply it over another hack
or an older version of this patch. The BPS file is a patch, not a game you can
open directly in an emulator.

SAVES
-----
Start a new game for the intended early-game balance and revised starting
stats. Loading an older save does not repeat the new-game stat setup.

Keep backups of your existing saves. Use normal in-game saves and avoid save
states made with an older version of the hack.

QUICK HELP
----------
- Patcher reports the wrong original file - Use a clean, headerless Lagoon
  (USA) ROM with the before-patching CRC shown at the top of this readme
- Game looks unchanged - Close the game and open the newly patched ROM rather
  than your original copy
- Starting stats look unchanged - Choose New Game instead of loading an old
  save or save state

INCLUDED FILES
--------------
- lagoon_redone_v10.bps - Gameplay patch
- readme.txt - Instructions and feature overview

Supply your own legally obtained ROM. No ROM is included.

Enjoy the adventure!
